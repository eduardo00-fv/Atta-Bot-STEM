#include <ESP32Servo.h> //3.0.2
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <string>
#include <Preferences.h> // Librería de almacenamiento de preferencias/credenciales para ESP32

#include <FastLED.h> //Nota: Se debe instalar la librería FastLED desde el gestor de librerías de Arduino IDE

#define LED_PIN     2   // IO02, connected to DIN
#define NUM_LEDS    1   // single onboard WS2812B
#define LED_TYPE    WS2812B
#define COLOR_ORDER GRB

CRGB leds[NUM_LEDS];


using namespace std;

// Robot constants

Preferences prefs;

float rightPulsesPerRev = 0;
float leftPulsesPerRev = 0;
float kpSpeed = 0;
float kiSpeed = 0;
float kdSpeed = 0.0;
String deviceName = "";

// Valores seguros usados solamente cuando el ESP32 aún no tiene una
// configuración guardada. Después de la primera ejecución los valores viven
// en la memoria no volátil (NVS) y una nueva carga del firmware no los borra.
const char *defaultDeviceName = "Atta-V-02";
const float defaultRightPulsesPerRev = 820.0;
const float defaultLeftPulsesPerRev = 820.0;
const float defaultKpSpeed = 2.0;
const float defaultKiSpeed = 2.0;
const float defaultKdSpeed = 0.0;

// Clave de acceso físico por USB. Cámbiela antes de distribuir el firmware.
const char *developerPassword = "AttaDev2026";
bool developerMode = false;
String serialCommand = "";

// Límites/calibración de los servos. No son const porque se cargan desde NVS.
int neutralAngle = 75;
int activateAngle = 85;
int deactivateAngle = 50;
int velocidadPositiva = 170;
int velocidadNegativa = 135;
int velocidadNeutra = 145;

void writeDefaultConfigIfMissing() {
  prefs.begin("Atta-Creds", false);
  if (!prefs.isKey("deviceName")) prefs.putString("deviceName", defaultDeviceName);
  if (!prefs.isKey("Rppr")) prefs.putFloat("Rppr", defaultRightPulsesPerRev);
  if (!prefs.isKey("Lppr")) prefs.putFloat("Lppr", defaultLeftPulsesPerRev);
  if (!prefs.isKey("kp")) prefs.putFloat("kp", defaultKpSpeed);
  if (!prefs.isKey("ki")) prefs.putFloat("ki", defaultKiSpeed);
  if (!prefs.isKey("kd")) prefs.putFloat("kd", defaultKdSpeed);
  if (!prefs.isKey("servoNeutral")) prefs.putInt("servoNeutral", neutralAngle);
  if (!prefs.isKey("servoActive")) prefs.putInt("servoActive", activateAngle);
  if (!prefs.isKey("servoInactive")) prefs.putInt("servoInactive", deactivateAngle);
  if (!prefs.isKey("servoForward")) prefs.putInt("servoForward", velocidadPositiva);
  if (!prefs.isKey("servoReverse")) prefs.putInt("servoReverse", velocidadNegativa);
  if (!prefs.isKey("servoStop")) prefs.putInt("servoStop", velocidadNeutra);
  prefs.end();
}

void loadConfig() {
  writeDefaultConfigIfMissing();
  prefs.begin("Atta-Creds", true); // true = read-only
  deviceName = prefs.getString("deviceName", defaultDeviceName);
  rightPulsesPerRev = prefs.getFloat("Rppr", defaultRightPulsesPerRev);
  leftPulsesPerRev = prefs.getFloat("Lppr", defaultLeftPulsesPerRev);
  kpSpeed = prefs.getFloat("kp", defaultKpSpeed);
  kiSpeed = prefs.getFloat("ki", defaultKiSpeed);
  kdSpeed = prefs.getFloat("kd", defaultKdSpeed);
  neutralAngle = prefs.getInt("servoNeutral", neutralAngle);
  activateAngle = prefs.getInt("servoActive", activateAngle);
  deactivateAngle = prefs.getInt("servoInactive", deactivateAngle);
  velocidadPositiva = prefs.getInt("servoForward", velocidadPositiva);
  velocidadNegativa = prefs.getInt("servoReverse", velocidadNegativa);
  velocidadNeutra = prefs.getInt("servoStop", velocidadNeutra);
  prefs.end();
}

const int samplingTime = 25; // units: miliseconds
//const float rightPulsesPerRev = 834; // number of pulses from a single encoder output, for the right motor
//const float leftPulsesPerRev = 834; // number of pulses from a single encoder output, for the left motor
const float wheelRadius = 22; // Wheel circumference = 139.5mm
const float distanceWheelToWheel = 120; // actualizado a chasís v2.4 
const float distanceCenterToWheel = distanceWheelToWheel / 2 ; // Turning radius of the robot, distance in mm between the center and one wheel

// Constants for PID control with samplingTime = 25ms
const float targetSpeed = 90.0; // Target speed for the robot in mm/s
//const float kpSpeed = 2; // Proportional constant for speed control 0.75, 1.1
//const float kiSpeed = 2; // Integral constant for speed control
//const float kdSpeed = 0.0; // Derivative constant for speed control (set to zero for no derivative action)

// Constants for PID control implementation
const int minIntegralErrorSpeed = -255; // Minimum value for integral error to avoid windup
const int maxIntegralErrorSpeed = 255; // Maximum value for integral error to avoid windup

const int upperDutyCycleLimitSpeed = 200; // Maximum allowed PWM value for speed control
const int lowerDutyCycleLimitSpeed = 60; // Minimum allowed PWM value for speed control

// Constants for RGB LED configuration
const int duracionParpadeoLed = 500;
const int duracionIndicadorRecibeProgra = 100;//2000;

// Constants for Bluetooth connection
const int esperaBT = 500;
unsigned long tiempoPasadaLecturaBT = 0;

// Constante para determinar cuánto tiempo esperar a la hora de desactivar/activar el lápiz
const int esperaMovimientoServo = 100;

// Constante para evasión de obstáculos
const int distRetrocesoObstaculo = 50;

// Constante para tener siempre activos (o no) los sensores inferiores (trackers)
const bool trackersSiempreActivos = false;

// Error accumulation for speed PID control
float sumErrorVelRight = 0; // Accumulated integral error for the right wheel
float prevErrorVelRight = 0; // Previous error value for the right wheel (used for derivative calculation)
float sumErrorVelLeft = 0; // Accumulated integral error for the left wheel
float prevErrorVelLeft = 0; // Previous error value for the left wheel (used for derivative calculation)

int distanceTraveled = 0; // Variable to track the total distance traveled by the robot


int prevPWMRight = 0;
int prevPWMLeft = 0;
bool prevReverse = 0;


// For speed sampling
unsigned long previousTime = 0;

// Cambio del delay
// Keeping it explicit makes it safe to tune from measurements without blocking the loop.
const unsigned long stopSettlingTime = 500;
unsigned long stopStartTime = 0;
bool waitingForStopSettle = false;

// Variables to keep track of the encoder state
volatile long leftEncoderPos = 0; // Current position of the left encoder (in ticks)
long leftTicksForSpeed = 0; // Number of encoder ticks counted for left wheel speed calculation
long leftPrevTicks = 0; // Previous encoder tick count for the left wheel (used to calculate speed) 
volatile long rightEncoderPos = 0; // Current position of the right encoder (in ticks)
long rightTicksForSpeed = 0; // Number of encoder ticks counted for right wheel speed calculation
long rightPrevTicks = 0; // Previous encoder tick count for the right wheel (used to calculate speed)

// Variables to store the servo position (loaded from Preferences at startup)
int set = 0;

//Variables del servomotor 360 del set de herramientas
const int pinServo360 = 23;

// Create a Servo object to control the MG90S
Servo myServo;
Servo servoHerramientaSet;


// Define pin for the servo signal
const int servoPin = 26;

// Define the encoder pins
const int rightEncoderA = 27; // Pin for the right encoder's channel A
const int rightEncoderB = 33; // Pin for the right encoder's channel B

const int leftEncoderA = 32; // Pin for the left encoder's channel A
const int leftEncoderB = 35; // Pin for the left encoder's channel B

// Motor control pins
const int rightMotorM1 = 14;   // Direction control pin 1 for the right motor
const int rightMotorM2 = 12;   // Direction control pin 2 for the right motor


const int leftMotorM1 = 13;   // Direction control pin 1 for the left motor
const int leftMotorM2 = 15;   // Direction control pin 1 for the left motor

// Obstacle sensors setup
const int rightInfraredSensor = 4; // Pin for the right infrared obstacle sensor
const int leftInfraredSensor = 25;  // Pin for the left infrared obstacle sensor

// Tracker sensors setup
const int rightTrackerSensor = 34;  // Pin for the right tracker sensor
const int leftTrackerSensor = 39;   // Pin for the left tracker sensor

// LED RGB setup
const int pinLedRgbRojo = 5; 
const int pinLedRgbVerde = 18; 
const int pinLedRgbAzul = 19;
const int pinBateriaBaja = 21;

unsigned long tiempoDeEncendidoDeLed = 0; // Variable para llevar los tiempos de parpadeo/cambio en led RGB

int currentStep = 0; // Variable to keep track of the current step
unsigned long stepStartTime = 0; // Variable to track the start time of each step


//variables máquina de estados
enum posibles_Estados {ESPERA=0, LEE_MEMORIA, MOVERSE, GIRAR, DETENERSE, CICLO, OBSTACULOS, MOVIMIENTO_OBSTACULO, HERRAMIENTA, HERRAMIENTA_SET, IF, WHILE, NADA};
posibles_Estados estado = ESPERA;
bool giro_listo = false;
bool movimiento_listo = true; 
bool obstaculos_activo = false;
bool primer_ciclo = true;
bool retroceso_listo = false;
bool obstaculo_detectado=false;
bool paro_emergencia=false;



//variables para comunicación Bluetooth
string mensajeBLE="ATINIAV020GD030CI003RE010GI090CIFINATFIN";  

//***************************************************************************************
// Global variables and callback classes for native ESP32 BLE (BLEDevice library)
//***************************************************************************************

BLEServer *pServer = NULL;               // Represents this ESP32 acting as a BLE server
BLECharacteristic *pCharacteristic = NULL; // Pointer to the read/write characteristic 

bool deviceConnected = false;   // true while a central (the App) is connected 
bool nuevoMensajeBLE = false;   // true when a new write has arrived and hasn't been processed yet
string mensajeBLEBuffer = "";   // Temporary storage for the incoming message, filled inside the callback

//***************************************************************************************
// Callback class for connection/disconnection events.
// onConnect/onDisconnect are called automatically by the BLE stack 
//***************************************************************************************
class MyServerCallbacks: public BLEServerCallbacks {
    void onConnect(BLEServer* pServer) {
      deviceConnected = true;
    }

    void onDisconnect(BLEServer* pServer) {
      deviceConnected = false;
      // IMPORTANT: native ESP32 BLE does NOT restart advertising automatically
      // after a disconnect. Without this, the device becomes invisible to new
      // connections after the first disconnect. We'll call this here so a phone
      // can always find and reconnect to the robot.
      pServer->getAdvertising()->start();
    }
};

//***************************************************************************************
// Callback class for write events on the characteristic.
// onWrite is called automatically the moment the App writes a new value 
//***************************************************************************************
class MyCharacteristicCallbacks: public BLECharacteristicCallbacks {
    void onWrite(BLECharacteristic *pCharacteristic) {
      String valorRecibido = pCharacteristic->getValue();
      if (valorRecibido.length() > 0) {
        mensajeBLEBuffer = string(valorRecibido.c_str());
        nuevoMensajeBLE = true;
      }
    }
};

//apuntadores y variables para la lista de instrucciones
enum posibles_Instrucciones {inst_Avanzar=1, inst_Retroceder, inst_GiroIzquierdo, inst_GiroDerecho, 
inst_CicloInicia, inst_CicloFin, inst_ObstaculoInicia, inst_ObstaculoFin, inst_HerramientaInicia, inst_HerramientaFin, inst_FinalMsg,
inst_HerramientaSet, inst_IfInicia,inst_Else, inst_IfFinal, inst_WhileInicia, inst_WhileFinal};
short lista_instrucciones[100][2];
short inst_final = 0;
short inst_actual = 0;
short instruccion = 0;
short valor_instruccion = 0;
short inst_inicio_ciclo = 0;
short cantidad_ciclos = 0;

//Variables para las flags para los estados del LED RGB
bool flagBluetooth = 0;
bool flagEjecucion = 0;
bool flagObstaculo = 0;
bool flagParar = 0;
bool recibeProgra = 0;
bool flancoNegRecibeProgra = 0;
unsigned long recibePrograTiempo0 = 0;

//Variables de control del flujo de bifurcaciones
// banderas de control de bifurcaciones
bool ignorarHastaIFFIN = false;
bool ignorarHastaElse = false;
bool ignorarHastaWHILEFIN = false;
// registros de anidacion WHILE
short indicesWhile[5] = {};
short anidamientoWhile = 0;
short anidamientoWhileIgnorar=0;
// registros de anidacion IF
short anidamientoIF=0;
short anidamientoIFIgnorar=0;

// Funciones de control de flujo 
bool ejecutandoRamaIf[5] = {};
const short sensorIzquierdoSobreNegro = 0;
const short sensorIzquierdoSobreBlanco = 10;

const short sensorDerechoSobreNegro = 0;
const short sensorDerechoSobreBlanco = 1;

const short sensorNoImporta = 999; // Else sin condicion
// traker son los del suelo
const short mientras = 0;
const short mientrasNo = 100; 

// saqué los bool de lectura a globales

  bool lecturaInfrarrojoDerecho;
  bool lecturaInfrarrojoIzquierdo;
  bool lecturaSensorTrackerDerecho;
  bool lecturaSensorTrackerIzquierdo;

// Constantes del set de herramientas
const short garraAbrir = 101; 
const short garraCerrar = 1;
const short gruaSubir = 102;
const short gruaBajar = 2;

const short posicionHerramientaPositiva = 1; // Garra abierta, Grua arriba
const short posicionHerramientaNegativa = 2; // Garra cerrada, grua abajo
short posicionHerramienta = 0; // al prender el robot no se conoce la posicion de la herramienta. La primera ejecución se confía en el usuario, para la segunda ejecución ya se conoce la posicion

const short tiempoGarra = 700;//###;
const short tiempoGrua = 4000;//###;

short tiempoDeAccion=0;
short velocidad=velocidadNeutra; 

//******************************************************************************************************************
// Function that updates the position of the right wheel encoder.
//
// This function increments the encoder position counter for the right wheel each time it is called. The counter 
// reflects the accumulated encoder pulses, allowing for the calculation of distance or speed based on pulses.
//
//******************************************************************************************************************
void rightUpdateEncoder() {
  // Update encoder positions based on direction
  rightEncoderPos ++;

}

//******************************************************************************************************************
// Function that updates the position of the left wheel encoder.
//
// This function increments the encoder position counter for the left wheel each time it is called. The counter 
// reflects the accumulated encoder pulses, which can be used to determine distance or speed based on pulse count.
//
//******************************************************************************************************************
void leftUpdateEncoder() {
  // Update encoder positions based on direction
  leftEncoderPos ++;
}

void printDeveloperConfig() {
  Serial.println("Configuracion guardada (NVS):");
  Serial.printf("  device=%s  rppr=%.2f  lppr=%.2f  kp=%.3f  ki=%.3f  kd=%.3f\n",
                deviceName.c_str(), rightPulsesPerRev, leftPulsesPerRev,
                kpSpeed, kiSpeed, kdSpeed);
  Serial.printf("  neutral=%d  active=%d  inactive=%d\n",
                neutralAngle, activateAngle, deactivateAngle);
  Serial.printf("  forward=%d  reverse=%d  stop=%d\n",
                velocidadPositiva, velocidadNegativa, velocidadNeutra);
}

void printDeveloperHelp() {
  Serial.println("DEV <clave>              abre el modo desarrollador");
  Serial.println("SHOW                      muestra todos los valores guardados");
  Serial.println("SET <campo> <valor>      guarda el valor inmediatamente");
  Serial.println("  Campos: device, rppr, lppr, kp, ki, kd, neutral, active, inactive, forward, reverse, stop");
  Serial.println("TEST <0-180>              mueve temporalmente el servo de lapiz");
  Serial.println("EXIT                      cierra el modo desarrollador");
}

bool parseFloatValue(const String &text, float &value) {
  char *end;
  value = strtof(text.c_str(), &end);
  return end != text.c_str() && *end == '\0';
}

bool saveDeveloperValue(String field, String value) {
  field.toLowerCase();
  value.trim();
  prefs.begin("Atta-Creds", false);

  if (field == "device" && value.length() > 0 && value.length() <= 31) {
    deviceName = value;
    prefs.putString("deviceName", deviceName);
  } else if (field == "rppr" || field == "lppr" || field == "kp" || field == "ki" || field == "kd") {
    float number;
    if (!parseFloatValue(value, number) || number < 0 || ((field == "rppr" || field == "lppr") && number == 0)) {
      prefs.end();
      return false;
    }
    if (field == "rppr") { rightPulsesPerRev = number; prefs.putFloat("Rppr", number); }
    if (field == "lppr") { leftPulsesPerRev = number; prefs.putFloat("Lppr", number); }
    if (field == "kp") { kpSpeed = number; prefs.putFloat("kp", number); }
    if (field == "ki") { kiSpeed = number; prefs.putFloat("ki", number); }
    if (field == "kd") { kdSpeed = number; prefs.putFloat("kd", number); }
  } else if (field == "neutral" || field == "active" || field == "inactive" ||
             field == "forward" || field == "reverse" || field == "stop") {
    float number;
    if (!parseFloatValue(value, number) || number < 0 || number > 180 || number != (int)number) {
      prefs.end();
      return false;
    }
    int angle = (int)number;
    if (field == "neutral") { neutralAngle = angle; prefs.putInt("servoNeutral", angle); }
    if (field == "active") { activateAngle = angle; prefs.putInt("servoActive", angle); }
    if (field == "inactive") { deactivateAngle = angle; prefs.putInt("servoInactive", angle); }
    if (field == "forward") { velocidadPositiva = angle; prefs.putInt("servoForward", angle); }
    if (field == "reverse") { velocidadNegativa = angle; prefs.putInt("servoReverse", angle); }
    if (field == "stop") { velocidadNeutra = angle; prefs.putInt("servoStop", angle); }
  } else {
    prefs.end();
    return false;
  }

  prefs.end();
  return true;
}

void processSerialCommand(String command) {
  command.trim();
  if (command.length() == 0) return;
  String upper = command;
  upper.toUpperCase();

  if (!developerMode) {
    if (upper.startsWith("DEV ") && command.substring(4) == developerPassword) {
      developerMode = true;
      Serial.println("Modo desarrollador abierto.");
      printDeveloperHelp();
    } else {
      Serial.println("Acceso restringido. Use DEV <clave>.");
    }
    return;
  }

  if (upper == "HELP" || upper == "?") {
    printDeveloperHelp();
  } else if (upper == "SHOW") {
    printDeveloperConfig();
  } else if (upper == "EXIT") {
    developerMode = false;
    Serial.println("Modo desarrollador cerrado.");
  } else if (upper.startsWith("TEST ")) {
    float angle;
    if (parseFloatValue(command.substring(5), angle) && angle >= 0 && angle <= 180 && angle == (int)angle) {
      myServo.write((int)angle);
      Serial.printf("Servo de lapiz movido temporalmente a %d. No se guardo ningun cambio.\n", (int)angle);
    } else {
      Serial.println("TEST requiere un entero entre 0 y 180.");
    }
  } else if (upper.startsWith("SET ")) {
    int separator = command.indexOf(' ', 4);
    if (separator > 4 && saveDeveloperValue(command.substring(4, separator), command.substring(separator + 1))) {
      Serial.println("Valor guardado en NVS. Se conservara aunque cargue firmware nuevo.");
    } else {
      Serial.println("SET invalido. Use HELP para ver los campos y rangos.");
    }
  } else {
    Serial.println("Comando desconocido. Use HELP.");
  }
}

void readDeveloperSerial() {
  while (Serial.available()) {
    char character = (char)Serial.read();
    if (character == '\r') continue;
    if (character == '\n') {
      processSerialCommand(serialCommand);
      serialCommand = "";
    } else if (serialCommand.length() < 95) {
      serialCommand += character;
    } else {
      serialCommand = "";
      Serial.println("Comando demasiado largo.");
    }
  }
}


void setup() {
  Serial.begin(115200);
  loadConfig(); // Lee (o inicializa una vez) la configuracion persistente.

  Serial.print("Loaded device name: [");
  Serial.print(deviceName);
  Serial.println("]");
  Serial.println("Serial listo. Para configurar: DEV <clave>");

  FastLED.addLeds<LED_TYPE, LED_PIN, COLOR_ORDER>(leds, NUM_LEDS);
  FastLED.setBrightness(255); 

  // Set the PWM properties (50 Hz is typical for servos)
  myServo.setPeriodHertz(50);    // Standard 50Hz servo
  myServo.attach(servoPin, 500, 2400);  // Attach the servo on the pin with min/max pulse widths
  myServo.write(neutralAngle);   // Lleva el lápiz a neutral al encender el Atta

  // Set encoder pins as inputs
  pinMode(rightEncoderA, INPUT_PULLUP);
  pinMode(rightEncoderB, INPUT_PULLUP);

  pinMode(leftEncoderA, INPUT_PULLUP);
  pinMode(leftEncoderB, INPUT_PULLUP);

  pinMode(rightMotorM1, OUTPUT);
  pinMode(rightMotorM2, OUTPUT);

  pinMode(leftMotorM1, OUTPUT);
  pinMode(leftMotorM2, OUTPUT);

  //Obstacle sensors set up
  pinMode(rightInfraredSensor, INPUT);
  pinMode(leftInfraredSensor, INPUT);

  // Tracker sensors set up
  pinMode(rightTrackerSensor, INPUT_PULLDOWN);
  pinMode(leftTrackerSensor, INPUT_PULLDOWN);

  // LED RGB set up
  pinMode(pinLedRgbRojo, OUTPUT);
  pinMode(pinLedRgbAzul, OUTPUT);
  pinMode(pinLedRgbVerde, OUTPUT);

  // Setup servo360
  pinMode(pinServo360, OUTPUT);
  servoHerramientaSet.attach(pinServo360);
  servoHerramientaSet.write(velocidadNeutra);

  // Señal de batería baja set up
  pinMode(pinBateriaBaja, INPUT_PULLUP);

  // Attach interrupts to encoder pins
  attachInterrupt(digitalPinToInterrupt(rightEncoderA), rightUpdateEncoder, CHANGE);
  attachInterrupt(digitalPinToInterrupt(rightEncoderB), rightUpdateEncoder, CHANGE);

  attachInterrupt(digitalPinToInterrupt(leftEncoderA), leftUpdateEncoder, CHANGE);
  attachInterrupt(digitalPinToInterrupt(leftEncoderB), leftUpdateEncoder, CHANGE);

    //Inicialización comunicación bluetooth BLE

  //***************************************************************************************
  // Inicialización nativa de BLE para ESP32 
  //***************************************************************************************

  // Establece el nombre que se anuncia del dispositivo 
  //BLEDevice::init(deviceName.c_str()); // Use the device name loaded from preferences
  BLEDevice::init(deviceName);
  // Crea el objeto servidor y registra los callbacks de conexión/desconexión
  // para que deviceConnected se actualice automáticamente
  pServer = BLEDevice::createServer();
  pServer->setCallbacks(new MyServerCallbacks()); // Callback es cuando un dispositivo se conecta al server

  // Crea el servicio usando el UUID. Este número es un acuerdo entre la APP y el robot. Se puede cambiar a otro UUID, pero se debe cambiar también en la APP.
  BLEService *pService = pServer->createService("4fafc201-1fb5-459e-8fcc-c5c9c331914b");

  // Crea el característico usando el UUID y permisos de
  // Lectura/Escritura 
  pCharacteristic = pService->createCharacteristic(
                      "beb5483e-36e1-4688-b7f5-ea07361b26a8", //Este número es un acuerdo entre la APP y el robot. Se puede cambiar a otro UUID, pero se debe cambiar también en la APP.
                      BLECharacteristic::PROPERTY_READ |
                      BLECharacteristic::PROPERTY_WRITE
                    );

  // Registra el callback onWrite  para que nuevoMensajeBLE se active
  // automáticamente 
  pCharacteristic->setCallbacks(new MyCharacteristicCallbacks());

  // Inicia el servicio — debe ocurrir después de crear todos los característicos
  pService->start();

  // Hace que el servicio sea detectable, y luego inicia el anuncio (advertising)
  pServer->getAdvertising()->addServiceUUID("4fafc201-1fb5-459e-8fcc-c5c9c331914b");
  pServer->getAdvertising()->start(); 

  tiempoDeEncendidoDeLed = millis();
}



void loop() {
  readDeveloperSerial();
  

  lecturaInfrarrojoDerecho=digitalRead(rightInfraredSensor);
  lecturaInfrarrojoIzquierdo=digitalRead(leftInfraredSensor);
  lecturaSensorTrackerDerecho=digitalRead(rightTrackerSensor);
  lecturaSensorTrackerIzquierdo=digitalRead(leftTrackerSensor);
  int flagBateriaBaja = digitalRead(pinBateriaBaja);


  //Máquina de estados principal
  switch (estado) {

    case ESPERA:  { 
      // Leer la conexión BLE periódicamente
      if (millis() >= tiempoPasadaLecturaBT + esperaBT) {
        leerBluetooth();
        tiempoPasadaLecturaBT = millis();
      }

      //Lógica de estado siguiente
      if (flancoNegRecibeProgra) {
          flagEjecucion = 1; 
          estado = LEE_MEMORIA;
          inst_actual = 0;
      } else if (paro_emergencia) { // si se recibe un comando de detener mientras está en ESPERA, se ignora
        flagParar = 0; 
        paro_emergencia = 0;
      }
      break;
    }

    case LEE_MEMORIA:  { 
      if ( inst_actual != inst_final ){ // avanza en memoria de instrucciones
        instruccion = lista_instrucciones[inst_actual][0];
        valor_instruccion = lista_instrucciones[inst_actual][1];
        inst_actual++;         

      } 
      
      //Lógica de estado siguiente
      if (inst_actual == inst_final) { 
        estado = ESPERA;
        inst_actual = 0;
        flagEjecucion = 0;

      } else if (ignorarHastaIFFIN || ignorarHastaElse || ignorarHastaWHILEFIN){ //se leen e ignoran segmentos de instrucciones hasta marcas de ramas
        //if
          if ((ignorarHastaIFFIN || ignorarHastaElse) && (instruccion == inst_IfInicia)){
            anidamientoIFIgnorar++; // debe ignorar un "fin" extra

          } else if ((ignorarHastaIFFIN || ignorarHastaElse) && (instruccion == inst_IfFinal)){            
            if (anidamientoIFIgnorar == anidamientoIF){ // se llegó al fin de una rama
              ignorarHastaIFFIN = false;
              ignorarHastaElse = false;
              estado = IF;
              } else {
                anidamientoIFIgnorar--;
              }

          } else if (ignorarHastaElse && (instruccion == inst_Else)){
            ignorarHastaElse = false; // se llegó al inicio de una nueva rama
            estado = IF;

          } else if (ignorarHastaWHILEFIN){ // Whiles
            if (instruccion == inst_WhileInicia){
              anidamientoWhileIgnorar++; // se debe ignorar un fin extra

            } else if (instruccion == inst_WhileFinal){
              if(anidamientoWhileIgnorar == anidamientoWhile){
                ignorarHastaWHILEFIN = false; //se llegó al fin del ciclo
              } else {
                anidamientoWhileIgnorar--;
              }
            }
          }  // estado se mantiene igual, se salta el resto de comparaciones y lee nueva instruccion   
      
      }else if (instruccion == inst_Avanzar) {
        rightEncoderPos = 0; 
        leftEncoderPos = 0;
        estado = MOVERSE;
      }else if (instruccion == inst_Retroceder) {
        estado = MOVERSE;
        valor_instruccion = valor_instruccion * -1;
        rightEncoderPos = 0; 
        leftEncoderPos = 0;

      }else if (instruccion == inst_GiroIzquierdo) {
        estado = GIRAR;
        valor_instruccion = valor_instruccion * -1;
        rightEncoderPos = 0;
        leftEncoderPos = 0;

      }else if (instruccion == inst_GiroDerecho) {
        estado = GIRAR;
        rightEncoderPos = 0;
        leftEncoderPos = 0;
      
      }else if (instruccion == inst_CicloInicia  ||  instruccion == inst_CicloFin) {
        estado = CICLO;

      }else if (instruccion == inst_ObstaculoInicia  ||  instruccion == inst_ObstaculoFin) {
        estado = OBSTACULOS;
      
      }else if (instruccion == inst_HerramientaInicia  ||  instruccion == inst_HerramientaFin) {
        estado = HERRAMIENTA;

      } else if (instruccion == inst_HerramientaSet) {
        estado = HERRAMIENTA_SET;

      } else if (instruccion == inst_IfInicia || instruccion == inst_Else || instruccion == inst_IfFinal){
        estado = IF;

      } else if (instruccion == inst_WhileInicia || instruccion == inst_WhileFinal){
        estado = WHILE;
      }

      break; 
    }
    
    case MOVERSE: {

      //Ejecuta el estado de avanzar o retroceder
      //(es el mismo pero con distancia negativa)
      movimiento_listo= advanceDesiredDistance(valor_instruccion*10);

      // Leer la conexión BLE periódicamente
      if (millis() >= tiempoPasadaLecturaBT + esperaBT) {
        leerBluetooth();
        tiempoPasadaLecturaBT = millis();
      }

      //Lógica estado siguiente
      if (paro_emergencia) { 
        estado = DETENERSE;

      } else if ( movimiento_listo ) {
        estado = DETENERSE;
        
      } else if ((trackersSiempreActivos || obstaculos_activo) && (lecturaSensorTrackerDerecho||lecturaSensorTrackerIzquierdo)) {
        obstaculo_detectado=true;
        flagObstaculo = 1;
        estado=DETENERSE;

      } else if (obstaculos_activo) {
        if (!lecturaInfrarrojoDerecho||!lecturaInfrarrojoIzquierdo){
          obstaculo_detectado=true;
          flagObstaculo = 1;
          estado=DETENERSE;
        }
      }
      break;
    }

    case GIRAR: {

      //Ejecuta el estado de girar derecha o izquierda
      //(es el mismo pero con ángulo negativo)

      //giro
      movimiento_listo= turnDesiredAngle(valor_instruccion);

      // Leer la conexión BLE periódicamente
      if (millis() >= tiempoPasadaLecturaBT + esperaBT) {
        leerBluetooth();
        tiempoPasadaLecturaBT = millis();
      }

      //Lógica estado siguiente
      if (paro_emergencia) {
        estado = DETENERSE;

      }else if ( movimiento_listo ) {
        //movimiento_listo = false;
        estado = DETENERSE;

      } else if ((trackersSiempreActivos || obstaculos_activo) && (lecturaSensorTrackerDerecho||lecturaSensorTrackerIzquierdo)) {
        obstaculo_detectado=true;
        flagObstaculo = 1;
        estado=DETENERSE;

      } else if (obstaculos_activo) {
        if (!lecturaInfrarrojoDerecho||!lecturaInfrarrojoIzquierdo){
          obstaculo_detectado=true;
          flagObstaculo = 1;
          estado=DETENERSE;
        }
      }
      
      break;
    }

    case DETENERSE: {
      if (!waitingForStopSettle) {
        if (paro_emergencia || obstaculo_detectado) { //en caso de apretar STOP o detectar obstaculo
          flagEjecucion = 0;
          configureHBridge(false, 3, 0, 0); //Detiene el robot
        } // Ojo que la funcion avanzar y girar ya detiene el robot al final

        stopStartTime = millis();
        waitingForStopSettle = true;
        flagParar = 0;
      }

      // Keep the firmware responsive while the chassis settles after stopping.
      if (millis() - stopStartTime < stopSettlingTime) {
        break;
      }

      waitingForStopSettle = false;

      //Lógica estado siguiente
      if (paro_emergencia){
        paro_emergencia=false;
        estado = ESPERA;
      } else if (obstaculo_detectado){
        // Se reinician los valores de posición para que no tome en cuenta el movimiento recién interrumpido
        rightEncoderPos = 0;
        leftEncoderPos = 0;
        estado = MOVIMIENTO_OBSTACULO;
      } else {
        estado = LEE_MEMORIA;
      }
      break;
    }

    case CICLO: {

      if ( instruccion == inst_CicloInicia  &&  primer_ciclo ){ //inicio ciclo, primera vez
        cantidad_ciclos = valor_instruccion;  //guarda cantidad de ciclos, primero 
        primer_ciclo = false;
        inst_inicio_ciclo = inst_actual-1;  //almacena apuntador a inicio de ciclo
        cantidad_ciclos--; //resta el primer ciclo que se va a ejecutar

      }else if ( instruccion == inst_CicloInicia  &&  !primer_ciclo ) { //inicio de ciclo, resto de veces
        cantidad_ciclos--;  //resta 1 a la cantidad de ciclos

      }else if ( instruccion == inst_CicloFin  &&  cantidad_ciclos != 0 ) { //final de ciclo, ciclos pendientes
        inst_actual = inst_inicio_ciclo; //devuelve el apuntador al inicio del ciclo

      }else if ( instruccion == inst_CicloFin  &&  cantidad_ciclos == 0 ) { //final de ciclo, última vez
        primer_ciclo = true; //reset de variable
      }


      //Lógica estado siguiente
      estado = LEE_MEMORIA;
      break;
    }

    case OBSTACULOS: {

      //*Activa la bandera de si detectar obstáculos y luego la desactiva
      if ( instruccion == inst_ObstaculoInicia ){
        obstaculos_activo = true;
      }else if ( instruccion == inst_ObstaculoFin ) {
        obstaculos_activo = false;
      }

      //Lógica estado siguiente
      estado = LEE_MEMORIA;
      break;
    }

    case MOVIMIENTO_OBSTACULO: {
      // *Genera el movimiento despues que un obstaculo se detectó, el cual corresponde a un retroceso
      retroceso_listo=advanceDesiredDistance(-1* distRetrocesoObstaculo);
      obstaculo_detectado=false;
      flagObstaculo = 0;
      
      // Lógica estado siguiente
      if (retroceso_listo) {
        estado = ESPERA;
      } 
      break;
    }

    case HERRAMIENTA: {

      //*Activa la bandera de si detectar obstáculos y luego la desactiva
      if ( instruccion == inst_HerramientaInicia ){
        controlServo(true);
      }else if ( instruccion == inst_HerramientaFin ) {
        controlServo(false);
      }

      delay(esperaMovimientoServo); // para que el servo tenga tiempo de moverse antes de que el robot avance a la siguiente instrucción

      //Lógica estado siguiente
      estado = LEE_MEMORIA;
      break;
    }

    case NADA: {
      break;
    }

    case IF: {
      verSernsores();
      bifurcacionIF();
      estado = LEE_MEMORIA;
      break;
    }

    case WHILE: {
      // Leer la conexión BLE periódicamente por si se requiere salir de un loop infinito
      if (millis() >= tiempoPasadaLecturaBT + esperaBT) {
        leerBluetooth();
        tiempoPasadaLecturaBT = millis();
      }

      verSernsores();
      bifurcacionWHILE();
      estado = LEE_MEMORIA;
      break;
    }

    case HERRAMIENTA_SET: {
      accionarHerramientaSet();
      estado = LEE_MEMORIA;
      break;
    }


  }

  flancoNegRecibeProgra = 0;
  // Reseteo de la señal de recibeProgra
  if (recibeProgra && millis() > recibePrograTiempo0 + duracionIndicadorRecibeProgra) {
    recibePrograTiempo0 = millis();
    recibeProgra = 0;
    flancoNegRecibeProgra = 1;
  }

  // Se asigna el color del LED RGB
  ConfigurarEstadoLedRgb(flagBateriaBaja, flagBluetooth, flagEjecucion, flagObstaculo, recibeProgra, flagParar);

}

//*****************************************************************
// Procedimiento para observar las lecturas de los sensores inferiores
//******************************************************************************************************************

void verSernsores(){
  Serial.println("****************************");
  Serial.println(lecturaSensorTrackerIzquierdo);
  Serial.println(lecturaSensorTrackerDerecho);
}



//******************************************************************************************************************
// Procedimiento que realiza la comparación de las lectura de los sensores para determinar si se salta o ejecuta la rama IF
//
// @param {bool} condicionSensorIzquierdo - Booleano que indica si se busca que la lectura del sensor sea alta o baja
// @param {bool} condicionSensorDerecho - Booleano que indica si se busca que la lectura del sensor sea alta o baja
//******************************************************************************************************************

void validacionIf(bool condicionSensorIzquierdo, bool condicionSensorDerecho){
if (condicionSensorIzquierdo && condicionSensorDerecho){
    ejecutandoRamaIf[anidamientoIF] = true;    
  } else {
    ignorarHastaElse = true;
    anidamientoIFIgnorar = anidamientoIF;
  }
};

//******************************************************************************************************************
// Procedimiento de asignación de las condiciones de los sensores para los condicionales IF
// 
//******************************************************************************************************************

void condicionesIF(){
  // inicios de ramas segun condicionales
  switch (valor_instruccion) {
    case (sensorIzquierdoSobreNegro + sensorDerechoSobreNegro): {
      validacionIf (lecturaSensorTrackerIzquierdo, lecturaSensorTrackerDerecho );
      break;
    }

    case (sensorIzquierdoSobreNegro + sensorDerechoSobreBlanco): {
      validacionIf (lecturaSensorTrackerIzquierdo, !lecturaSensorTrackerDerecho );
      break;
    }

    case (sensorIzquierdoSobreBlanco + sensorDerechoSobreNegro): {
      validacionIf (!lecturaSensorTrackerIzquierdo, lecturaSensorTrackerDerecho );
      break;
    }      

    case (sensorIzquierdoSobreBlanco + sensorDerechoSobreBlanco): {
      validacionIf (!lecturaSensorTrackerIzquierdo, !lecturaSensorTrackerDerecho );
      break;
    }

    case (sensorNoImporta): {
      validacionIf(true, true);
      break;
    }
    
  }

}

//******************************************************************************************************************
// Procedimiento de ejecución de la lógica del flujo de las bifurcaciones IF
// 
//******************************************************************************************************************

void bifurcacionIF(){

  switch (instruccion){
    case (inst_IfInicia) : {
      anidamientoIF++;  
      condicionesIF();        
      break;
    }
    case (inst_Else) : {
        if (ejecutandoRamaIf[anidamientoIF]){
          ignorarHastaIFFIN = true;
          anidamientoIFIgnorar = anidamientoIF;
        } else {
          condicionesIF();
        }
      break;
    }
    case (inst_IfFinal) : {      
      ejecutandoRamaIf[anidamientoIF] = false;
      anidamientoIF--;
      break;
    }

  
  }

};



//******************************************************************************************************************
// Procedimiento que realiza la comparación de las lectura de los sensores para determinar si se salta o ejecuta la rama While
//
// @param {bool} condicionSensorIzquierdo - Booleano que indica si se busca que la lectura del sensor sea alta o baja
// @param {bool} condicionSensorDerecho - Booleano que indica si se busca que la lectura del sensor sea alta o baja
//******************************************************************************************************************


void validacionWhile(bool condicionSensorIzquierdo, bool condicionSensorDerecho){
  if (condicionSensorIzquierdo && condicionSensorDerecho){
    indicesWhile[anidamientoWhile]=inst_actual-1;
    anidamientoWhile++;
  } else {
    ignorarHastaWHILEFIN = true;
    anidamientoWhileIgnorar = anidamientoWhile;
  }
};

//******************************************************************************************************************
// Procedimiento que realiza la comparación de las lectura de los sensores para determinar si se salta o ejecuta la rama WhileNot
//
// @param {bool} condicionSensorIzquierdo - Booleano que indica si se busca que la lectura del sensor sea alta o baja
// @param {bool} condicionSensorDerecho - Booleano que indica si se busca que la lectura del sensor sea alta o baja
//******************************************************************************************************************

void validacionNotWhile(bool condicionSensorIzquierdo, bool condicionSensorDerecho){
  if (!(condicionSensorIzquierdo && condicionSensorDerecho)){
    indicesWhile[anidamientoWhile]=inst_actual-1;
    anidamientoWhile++;
  } else {
    ignorarHastaWHILEFIN = true;
    anidamientoWhileIgnorar = anidamientoWhile;
  }
};

//******************************************************************************************************************
// Procedimiento de ejecución de la lógica de las banderas de flujo de bifurcaciones While y WhileNot
// 
//******************************************************************************************************************

void bifurcacionWHILE(){
  if (instruccion == inst_WhileFinal){
    anidamientoWhile--;
    inst_actual = indicesWhile[anidamientoWhile];
    

  }else {

    switch (valor_instruccion){
      case (mientras + sensorIzquierdoSobreNegro + sensorDerechoSobreNegro): {
        validacionWhile(lecturaSensorTrackerIzquierdo,lecturaSensorTrackerDerecho);
        break;
      }

      case (mientras + sensorIzquierdoSobreNegro + sensorDerechoSobreBlanco): {
        validacionWhile(lecturaSensorTrackerIzquierdo,!lecturaSensorTrackerDerecho);
        break;
      }

      case (mientras + sensorIzquierdoSobreBlanco + sensorDerechoSobreNegro): {
        validacionWhile(!lecturaSensorTrackerIzquierdo,lecturaSensorTrackerDerecho);
        break;
      }      

      case (mientras + sensorIzquierdoSobreBlanco + sensorDerechoSobreBlanco): {
        validacionWhile(!lecturaSensorTrackerIzquierdo,!lecturaSensorTrackerDerecho);
        break;
      }

      case (mientrasNo + sensorIzquierdoSobreNegro + sensorDerechoSobreNegro): {
        validacionNotWhile(lecturaSensorTrackerIzquierdo,lecturaSensorTrackerDerecho);
        break;
      }

      case (mientrasNo + sensorIzquierdoSobreNegro + sensorDerechoSobreBlanco): {
        validacionNotWhile(lecturaSensorTrackerIzquierdo,!lecturaSensorTrackerDerecho);
        break;
      }

      case (mientrasNo + sensorIzquierdoSobreBlanco + sensorDerechoSobreNegro): {
        validacionNotWhile(!lecturaSensorTrackerIzquierdo,lecturaSensorTrackerDerecho);
        break;
      }      

      case (mientrasNo + sensorIzquierdoSobreBlanco + sensorDerechoSobreBlanco): {
        validacionNotWhile(!lecturaSensorTrackerIzquierdo,!lecturaSensorTrackerDerecho);
        break;
      }    

    }

  }

};


//******************************************************************************************************************
// Procedimiento que mueve la herramienta la velocidad y tiempo indicados por el tipo de acción de la herramienta
// 
//******************************************************************************************************************

void accionarMotorHerramientaSet(){
  servoHerramientaSet.write(velocidad);
  delay(tiempoDeAccion);
  servoHerramientaSet.write(velocidadNeutra);
  delay(100);
};

//******************************************************************************************************************
// Procedimiento que asigna la velocidad y tiempo de ejecución de la herramienta según el valor del comando
// 
//******************************************************************************************************************

void accionarHerramientaSet(){
  tiempoDeAccion=0;
  velocidad=velocidadNeutra;
  switch (valor_instruccion){
    case (garraAbrir) : {
      if (!(posicionHerramienta == posicionHerramientaPositiva)){
        tiempoDeAccion = tiempoGarra;
        velocidad = velocidadPositiva;
        accionarMotorHerramientaSet();
        posicionHerramienta=posicionHerramientaPositiva;
      };
      break;
    };

    case (garraCerrar) : {
      if (!(posicionHerramienta == posicionHerramientaNegativa)){
        tiempoDeAccion = tiempoGarra;
        velocidad = velocidadNegativa;
        accionarMotorHerramientaSet();
        posicionHerramienta=posicionHerramientaNegativa;
      };
      break;
    };

    case (gruaSubir) : {
      if (!(posicionHerramienta == posicionHerramientaPositiva)){
        tiempoDeAccion = tiempoGrua;
        velocidad = velocidadPositiva;
        accionarMotorHerramientaSet();
        posicionHerramienta=posicionHerramientaPositiva;
      };
      break;
    };
    
    case (gruaBajar) : {
      if (!(posicionHerramienta == posicionHerramientaNegativa)){
        tiempoDeAccion = tiempoGrua ;
        velocidad = velocidadNegativa;
        accionarMotorHerramientaSet();
        posicionHerramienta=posicionHerramientaNegativa;
      };
      break;
    };    

  };

};



//FUNCIONES DE INTERPRETACION DE MENSAJES

//***************************************************************************************
//Función que interpreta el mensaje recibido de la app de programación
//
//Revisa el mensaje que se recibió por Bluetooth BLE y revisa de 5 en 5 
//los caracteres. Los guarda en un array global luego de interpretar que 
//instrucción es y que valor tienen
//
//@param mensaje Cadena de 512 caracteres máximo recibidos
// 
//***************************************************************************************
void Interpreta_mensajeBLE (string mensaje) {

  for (int i = 0; i < mensaje.length(); i=i+5 ) { 
        
        string comando = mensaje.substr(i, 5);
        string instruccion = mensaje.substr(i, 2);
        string valor_instruccion =  mensaje.substr(i+2, 3);

        if (comando=="ATCOI") {
          //inst_actual = 0;
        
        } else if (comando == "ATCOF") {
          //inst_final = i/5;

        } else if (comando == "PARAR") {
          paro_emergencia = true;
          flagParar = 1;

        } else if (comando == "EJECU") {
          inst_actual = 0;
         
        } else if (comando == "ATINI") {
          inst_actual = 0;
        
        } else if (comando == "ATFIN") {
          inst_final = i/5;
        
        } else if (comando == "OBINI") {
          lista_instrucciones[inst_actual][0] = inst_ObstaculoInicia;
          lista_instrucciones[inst_actual][1] = 0;
          inst_actual++;

        } else if (comando == "OBFIN") {
          lista_instrucciones[inst_actual][0] = inst_ObstaculoFin;
          lista_instrucciones[inst_actual][1] = 0;
          inst_actual++;

        } else if (comando == "CIFIN"){
          lista_instrucciones[inst_actual][0] = inst_CicloFin;
          lista_instrucciones[inst_actual][1] = 0;
          inst_actual++;  

        } else if (instruccion == "CI" && comando != "CIFIN") {
          short valor = stoi (valor_instruccion);
          lista_instrucciones[inst_actual][0] = inst_CicloInicia;
          lista_instrucciones[inst_actual][1] = valor;
          inst_actual++;

        } else if (instruccion == "AV") {
          short valor = stoi (valor_instruccion);
          lista_instrucciones[inst_actual][0] = inst_Avanzar;
          lista_instrucciones[inst_actual][1] = valor;
          inst_actual++;

        } else if (instruccion == "RE") {
          short valor = stoi (valor_instruccion);
          lista_instrucciones[inst_actual][0] = inst_Retroceder;
          lista_instrucciones[inst_actual][1]= valor;
          inst_actual++;

        } else if (instruccion == "GI") {
          short valor = stoi (valor_instruccion);
          lista_instrucciones[inst_actual][0] = inst_GiroIzquierdo;
          lista_instrucciones[inst_actual][1] = valor;
          inst_actual++;

        } else if (instruccion == "GD") {
          short valor = stoi (valor_instruccion);
          lista_instrucciones[inst_actual][0] = inst_GiroDerecho;
          lista_instrucciones[inst_actual][1] = valor;
          inst_actual++;
        
        } else if (comando == "HEINI") {
          lista_instrucciones[inst_actual][0] = inst_HerramientaInicia;
          lista_instrucciones[inst_actual][1] = 0;
          inst_actual++;

        } else if (comando == "HEFIN") {
          lista_instrucciones[inst_actual][0] = inst_HerramientaFin;
          lista_instrucciones[inst_actual][1] = 0;
          inst_actual++;

        } else if (comando == "IFFIN"){
          lista_instrucciones[inst_actual][0] = inst_IfFinal;
          lista_instrucciones[inst_actual][1] = 0;
          inst_actual++;

        } else if (instruccion == "IF"){
          short valor = stoi (valor_instruccion);
          lista_instrucciones[inst_actual][0] = inst_IfInicia;
          lista_instrucciones[inst_actual][1] = valor;
          inst_actual++;

        } else if (instruccion == "EL"){
          short valor = stoi (valor_instruccion);
          lista_instrucciones[inst_actual][0] = inst_Else;
          lista_instrucciones[inst_actual][1] = valor;
          inst_actual++;

        } else if (comando == "WHFIN"){
          lista_instrucciones[inst_actual][0] = inst_WhileFinal;
          lista_instrucciones[inst_actual][1] = 0;
          inst_actual++;

        } else if (instruccion == "WH"){
          short valor = stoi (valor_instruccion);
          lista_instrucciones[inst_actual][0] = inst_WhileInicia;
          lista_instrucciones[inst_actual][1] = valor;
          inst_actual++;

        } else if (instruccion == "HE"){
          short valor = stoi (valor_instruccion);
          lista_instrucciones[inst_actual][0] = inst_HerramientaSet;
          lista_instrucciones[inst_actual][1] = valor;
          inst_actual++;
        }
  }
  inst_actual = 0; 
}

//***************************************************************************************
//Función que lee la conexión Bluetooth BLE
//
//Determina si el robot está conectado a alguna App, y en caso de estarlo verifica
//si llegó un mensaje nuevo. En tal caso, llama a la interpretación del nuevo mensaje.
//También determina si se trata de una instrucción para la que se debería parpadear el
//led en azul.
//***************************************************************************************
void leerBluetooth() {
  // deviceConnected is updated automatically by MyServerCallbacks 
  flagBluetooth = deviceConnected; // Este flag se usa para el parpadeo del led azul, que indica si hay conexión BLE.

  if (deviceConnected && nuevoMensajeBLE) {
    mensajeBLE = mensajeBLEBuffer;
    Serial.println(mensajeBLE.c_str());

    // Clears the flag so the same message isn't processed again next loop
    // replaces: caracteristico.writeValue("")
    nuevoMensajeBLE = false;

    Interpreta_mensajeBLE(mensajeBLE);
    if (!flagParar) {
      recibeProgra = 1;
      recibePrograTiempo0 = millis();
    }
  }
}





//******************************************************************************************************************
// Function that controls the servo based on the variable `set`. If `set` is 1, the tool is activated; otherwise, it is deactivated.
//
// This function adjusts the servo angle to activate or deactivate the tool based on the `set` value.
//
// @param set Value that determines whether the tool is activated (1) or deactivated (0).
//
// @return true Returns true upon successful action.
//******************************************************************************************************************
bool controlServo(bool set) {
  if (set) {
    // Activate the tool by setting it to 110 degrees
    myServo.write(activateAngle);
  } else { //Deactivate the tool by setting it to 180 degrees
    myServo.write(deactivateAngle);
  }
  delay(500); // so that the next action does not start before the servo stops moving
  return true;  // Action completed
}

//******************************************************************************************************************
// Function that controls the speed of the wheels using a PID controller based on the reference and actual speeds.
//
// This function calculates a PWM output for the motors by applying a PID control loop to match the actual speed to a setpoint.
//
// @param refSpeed The target speed for the motor.
// @param actualSpeed The current speed of the motor.
// @param sumErrorSpeed Accumulated integral error for the speed PID.
// @param prevErrorSpeed Previous speed error for the derivative calculation.
//
// @return The computed PWM signal as an integer to control the motor speed.
//******************************************************************************************************************
int controlWheelSpeed(float refSpeed, float actualSpeed, float& sumErrorSpeed, float& prevErrorSpeed) {
  
  // Calculate the error between the reference speed and the actual speed
  float errorSpeed = refSpeed - actualSpeed;

  // Update the integral error by accumulating the current error over time
  // Multiply by 0.01 to scale the contribution of the error (based on sampling time)
  sumErrorSpeed += errorSpeed * 0.01;

  // Constrain the integral error to avoid windup
  sumErrorSpeed = constrain(sumErrorSpeed, minIntegralErrorSpeed , maxIntegralErrorSpeed);

  // Calculate the derivative of the error (difference between current and previous error)
  float diffErrorSpeed = (errorSpeed - prevErrorSpeed);

  // PID control equation to calculate the control output
  float pidOutput = (kpSpeed * errorSpeed) + (kiSpeed * sumErrorSpeed) + (kdSpeed * diffErrorSpeed);

  // Constrain the PID output to avoid saturation and ensure it stays within motor PWM limits
  pidOutput = constrain((int)pidOutput, lowerDutyCycleLimitSpeed, upperDutyCycleLimitSpeed);

  // Update the previous error for the next iteration of the control loop
  prevErrorSpeed = errorSpeed;
  
  // Return the calculated PWM value as an integer
  return (int)pidOutput;
}

//******************************************************************************************************************
// Function that moves the robot a desired linear distance using PID control to maintain speed and direction.
//
// This function continuously calculates the speed of each wheel, adjusts the motor PWM values, and checks if the robot has reached the desired distance.
//
// @param desiredDistance The target distance in mm that the robot should travel.
//
// @return true if the desired distance is reached; false otherwise.
//******************************************************************************************************************
bool advanceDesiredDistance(int desiredDistance) {

  // Flag to indicate if the robot should move in reverse
  bool reverse = false;

  // Create a time condition using millis to apply a sampling time without delays
  unsigned long currentTime = millis(); // Get the current time in milliseconds
  unsigned long deltaTime = currentTime - previousTime; // Time elapsed since the last sample

  // Check if the elapsed time has reached the sampling time (10 ms)
  if (deltaTime >= samplingTime) {
    previousTime = currentTime; // Reset previous time for the next sample

    // Convert deltaTime to seconds
    float deltaTimeSec = deltaTime / 1000.0;


    // Calculate the number of encoder ticks since the last sample
    rightTicksForSpeed = rightEncoderPos - rightPrevTicks;
    leftTicksForSpeed = leftEncoderPos - leftPrevTicks;

    
    // Calculate the current speeds of both wheels based on the encoder ticks
    float actualSpeedLeft = calculateSpeed(leftTicksForSpeed, deltaTimeSec, 1); // Speed of the left wheel in mm/s
    float actualSpeedRight = calculateSpeed(rightTicksForSpeed, deltaTimeSec, 0); // Speed of the right wheel in mm/s

    // Update the previous encoder tick counts
    rightPrevTicks = rightEncoderPos;
    leftPrevTicks = leftEncoderPos;


    // Set desired speeds

    if (desiredDistance < 0) { // If the desired distance is negative, move in reverse
        reverse = true;
    }

    float speedSetPoint = targetSpeed; // Define the target speed for both wheels (in mm/s)

    // PID control loop for speed to calculate PWM values for both wheel
    int pwmRightWheel = controlWheelSpeed(speedSetPoint, actualSpeedRight, sumErrorVelRight, prevErrorVelRight);
    int pwmLeftWheel = controlWheelSpeed(speedSetPoint, actualSpeedLeft, sumErrorVelLeft, prevErrorVelLeft);



    // Determine if the PWM values for the right and left wheels have changed
    bool rightChanged = (prevPWMRight != pwmRightWheel); // Check if right wheel needs to be updated
    bool leftChanged = (prevPWMLeft != pwmLeftWheel); // Check if left wheel needs to be updated
    bool reverseChanged = (prevReverse != reverse); // Check if both wheels need to be updated

    // Update the H-Bridge configuration if there are changes in the PWM values
    if (rightChanged) {
      configureHBridge(reverse, 1, pwmRightWheel, pwmLeftWheel);// Update the right motor control
    }
    if (leftChanged) {
      configureHBridge(reverse, 2, pwmRightWheel, pwmLeftWheel);// Update the left motor control
    }
    if ((rightChanged && leftChanged) || reverseChanged) {
      configureHBridge(reverse, 3, pwmRightWheel, pwmLeftWheel); // Update both motors if both values changed or if direction changed
    }

    // Store the current PWM values for comparison in the next iteration
    prevPWMRight = pwmRightWheel;
    prevPWMLeft = pwmLeftWheel;
    prevReverse = reverse;

    
    // Calculate the distance traveled by the robot using encoder data
    float distanceTraveled = calculateLinearDistanceTraveled(leftEncoderPos, rightEncoderPos);

    // Check if the robot has traveled the desired distance
    if (abs(distanceTraveled) >= abs(desiredDistance)) {

      // If the desired distance is reached, stop the robot
      configureHBridge(reverse, 3, 0, 0);

      // Reset PID control values
      sumErrorVelRight = 0;
      prevErrorVelRight = 0;
      sumErrorVelLeft = 0;
      prevErrorVelLeft = 0;

      // Reset encoder tick counts
      rightPrevTicks = 0;
      leftPrevTicks = 0;

      rightEncoderPos = 0;
      leftEncoderPos = 0;

      return true; // Return true to indicate that the desired distance has been reached
    }

  }
  return false; // Return false if the robot has not yet reached the desired distance
}

//******************************************************************************************************************
// Function that turns the robot to a specified angle using PID control for each wheel's speed.
//
// This function calculates the speed of each wheel, updates the H-Bridge configuration to turn, and checks if the robot has turned to the desired angle.
//
// @param desiredAngle The target angle in degrees for the robot to turn.
//
// @return true if the desired angle is reached; false otherwise.
//******************************************************************************************************************
bool turnDesiredAngle (int desiredAngle) {

  // Flag to indicate if the robot should turn in counterClockwise
  bool counterClockwise = false;

  if (desiredAngle < 0) { // If the desired angle is negative, move in counterClockwise
    counterClockwise = true;
  }

  // Create a time condition using millis to apply a sampling time without delays
  unsigned long currentTime = millis(); // Get the current time in milliseconds
  unsigned long deltaTime = currentTime - previousTime; // Time elapsed since the last sample


  // Calculate the linear distance required for the given angle
  float desiredDistance = calculateLinearDistanceDesired(desiredAngle);

  // Check if the elapsed time has reached the sampling time (10 ms)
  if (deltaTime >= samplingTime) {
    previousTime = currentTime; // Reset previous time for the next sample

    // Convert deltaTime to seconds
    float deltaTimeSec = deltaTime / 1000.0;


    // Calculate the number of encoder ticks since the last sample
    rightTicksForSpeed = rightEncoderPos - rightPrevTicks;
    leftTicksForSpeed = leftEncoderPos - leftPrevTicks;

    
    // Calculate the current speeds of both wheels based on the encoder ticks
    float actualSpeedLeft = calculateSpeed(leftTicksForSpeed, deltaTimeSec, 1); // Speed of the left wheel in mm/s
    float actualSpeedRight = calculateSpeed(rightTicksForSpeed, deltaTimeSec, 0); // Speed of the right wheel in mm/s

    // Update the previous encoder tick counts
    rightPrevTicks = rightEncoderPos;
    leftPrevTicks = leftEncoderPos;


    // Set desired speeds

    float speedSetPoint = targetSpeed; // Define the target speed for both wheels (in mm/s)

    // PID control loop for speed to calculate PWM values for both wheel
    int pwmRightWheel = controlWheelSpeed(speedSetPoint, actualSpeedRight, sumErrorVelRight, prevErrorVelRight);
    int pwmLeftWheel = controlWheelSpeed(speedSetPoint, actualSpeedLeft, sumErrorVelLeft, prevErrorVelLeft);

    // Determine if the PWM values for the right and left wheels have changed
    bool rightChanged = (prevPWMRight != pwmRightWheel); // Check if right wheel needs to be updated
    bool leftChanged = (prevPWMLeft != pwmLeftWheel); // Check if left wheel needs to be updated

    // Update the H-Bridge configuration if there are changes in the PWM values
    if (rightChanged) {
      configureHBridgeTurn(counterClockwise, 1, pwmRightWheel, pwmLeftWheel);// Update the right motor control
    }
    if (leftChanged) {
      configureHBridgeTurn(counterClockwise, 2, pwmRightWheel, pwmLeftWheel);// Update the left motor control
    }
    if (rightChanged && leftChanged) {
      configureHBridgeTurn(counterClockwise, 3, pwmRightWheel, pwmLeftWheel); // Update both motors if both values changed
    }

    // Store the current PWM values for comparison in the next iteration
    prevPWMRight = pwmRightWheel;
    prevPWMLeft = pwmLeftWheel;

    // Calculate the distance traveled by the robot using encoder data
    float distanceTraveled = calculateLinearDistanceTraveled(leftEncoderPos, rightEncoderPos);

    // Check if the robot has traveled the desired distance
    if (abs(distanceTraveled) >= abs(desiredDistance)) {

      // If the desired distance is reached, stop the robot
      configureHBridgeTurn(counterClockwise, 3, 0, 0);

      // Reset PID control values
      sumErrorVelRight = 0;
      prevErrorVelRight = 0;
      sumErrorVelLeft = 0;
      prevErrorVelLeft = 0;

      // Reset encoder tick counts
      rightPrevTicks = 0;
      leftPrevTicks = 0;

      rightEncoderPos = 0;
      leftEncoderPos = 0;

      return true; // Return true to indicate that the desired distance has been reached
    }

  }
  return false; // Return false if the robot has not yet reached the desired distance
}

//******************************************************************************************************************
// Function that calculates the speed of a wheel based on encoder pulses and elapsed time.
//
// The function converts the number of pulses into a linear distance, then calculates the speed in mm/s based on the time interval.
//
// @param pulses The number of encoder pulses detected.
// @param deltaTime The time interval in seconds.
// @param motorID Whether the calculation is for the right (0) or left (1) motor.
//
// @return The calculated speed in mm/s.
//******************************************************************************************************************
float calculateSpeed(long pulses, float deltaTime, int motorID) {
    // Wheel circumference in mm
    float wheelCircumference = 2 * 3.1416 * wheelRadius;

    // Full revolutions based on the number of pulses
    float revolutions = 0;
    if (motorID == 0) { // for right motor
      revolutions = pulses / rightPulsesPerRev;
    } else { // for left motor (id = 1)
      revolutions = pulses / leftPulsesPerRev;
    }
    

    // Distance traveled in mm
    float distance = revolutions * wheelCircumference;

    //Speed mm/s

    float vel = distance / deltaTime;
    
    return vel;
}

//******************************************************************************************************************
// Function that configures the H-Bridge to control forward or reverse motion of each wheel based on PWM values and direction.
//
// This function sets the PWM for each motor pin depending on the motion direction and update mode.
//
// @param reverse Boolean indicating whether to move in reverse (true) or forward (false).
// @param update Mode to update specific wheels: 1 for right, 2 for left, 3 for both.
// @param pwmRightWheel PWM value for the right wheel.
// @param pwmLeftWheel PWM value for the left wheel.
//******************************************************************************************************************
void configureHBridge(bool reverse, int update, int pwmRightWheel, int pwmLeftWheel){

    // Check if right wheel should be updated (update == 1 or update == 3)
    if (update == 1 || update == 3) {
        if (!reverse) { // Set right wheel for forward direction
            analogWrite(rightMotorM1, pwmRightWheel); // Apply PWM to right motor for forward motion
            analogWrite(rightMotorM2, 0);             // Set right motor reverse pin to 0 (off)
        } else { // Set right wheel for reverse direction
            analogWrite(rightMotorM1, 0);             // Set right motor forward pin to 0 (off)
            analogWrite(rightMotorM2, pwmRightWheel); // Apply PWM to right motor for reverse motion
        }
    }

    // Check if left wheel should be updated (update == 2 or update == 3)
    if (update == 2 || update == 3) {
        if (!reverse) { // Set left wheel for forward direction
            analogWrite(leftMotorM1, pwmLeftWheel); // Apply PWM to left motor for forward motion
            analogWrite(leftMotorM2, 0);            // Set left motor reverse pin to 0 (off)
        } else { // Set left wheel for reverse direction
            analogWrite(leftMotorM1, 0);            // Set left motor forward pin to 0 (off)
            analogWrite(leftMotorM2, pwmLeftWheel); // Apply PWM to left motor for reverse motion
        }
    }
}


//******************************************************************************************************************
// Function that configures the H-Bridge for turning based on the specified direction and update mode.
//
// This function sets PWM values for each wheel's motor pins to achieve a clockwise or counterclockwise turn.
//
// @param counterClockwise Boolean indicating if the turn is counterclockwise (true) or clockwise (false).
// @param update Mode to update specific wheels: 1 for right, 2 for left, 3 for both.
// @param pwmRightWheel PWM value for the right wheel.
// @param pwmLeftWheel PWM value for the left wheel.
//******************************************************************************************************************
void configureHBridgeTurn(bool counterClockwise, int update, int pwmRightWheel, int pwmLeftWheel){

    // Check if right wheel should be updated (update == 1 or update == 3)
    if (update == 1 || update == 3) {
        if (!counterClockwise) { // Set right wheel for clockwise turn
            analogWrite(rightMotorM1, 0);  // Right motor pin M1 set to 0
            analogWrite(rightMotorM2, pwmRightWheel); // Right motor pin M2 set to PWM value
        } else { // Set right wheel for counterclockwise turn
            analogWrite(rightMotorM1, pwmRightWheel); // Right motor pin M1 set to PWM value
            analogWrite(rightMotorM2, 0);  // Right motor pin M2 set to 0
        }
    }

    // Check if left wheel should be updated (update == 2 or update == 3)
    if (update == 2 || update == 3) {
        if (!counterClockwise) { // Set left wheel for clockwise turn
            analogWrite(leftMotorM1, pwmLeftWheel); // Left motor pin M1 set to PWM value
            analogWrite(leftMotorM2, 0);  // Left motor pin M2 set to 0
        } else { // Set left wheel for counterclockwise turn
            analogWrite(leftMotorM1, 0);  // Left motor pin M1 set to 0
            analogWrite(leftMotorM2, pwmLeftWheel); // Left motor pin M2 set to PWM value
        }
    }
}

//******************************************************************************************************************
// Function that calculates the average linear distance traveled by the robot based on encoder pulses.
//
// This function converts the pulse count from both wheels to a linear distance, then averages both distances.
//
// @param leftPulseCount Pulse count for the left wheel encoder.
// @param rightPulseCount Pulse count for the right wheel encoder.
//
// @return The average distance traveled in mm.
//******************************************************************************************************************
float calculateLinearDistanceTraveled(long leftPulseCount, long rightPulseCount) {

  // Wheel circumference in mm
  float wheelCircumference = 2 * PI * wheelRadius;

  // Full revolutions based on the number of pulses
  float rightRevolutions = (float) rightPulseCount / rightPulsesPerRev;
  float leftRevolutions = (float) leftPulseCount / leftPulsesPerRev;

  // Distance traveled in mm
  float rightDistance = rightRevolutions * wheelCircumference;
  float leftDistance = leftRevolutions * wheelCircumference;

  // Calculate the average linear distance
  float linearDistance = (rightDistance + leftDistance) / 2.0;

  return linearDistance;
}


//******************************************************************************************************************
// Function that calculates the linear distance required for the robot to achieve a desired turning angle.
//
// This function computes the distance based on the angle input, assuming a circular path defined by the distance 
// between the wheels.
//
// @param desiredAngle The angle in degrees that the robot needs to turn.
//
// @return The calculated linear distance in mm required to achieve the desired turn.
//******************************************************************************************************************
float calculateLinearDistanceDesired(int desiredAngle) {

  // Calculate the linear distance based on the desired angle, assuming a circular path
  // Formula: (desiredAngle / 360) * π * distanceWheelToWheel
  float linearDesiredDistance = (desiredAngle / 360.0) * PI * distanceWheelToWheel;

  // Return the calculated linear distance
  return linearDesiredDistance;
}

//******************************************************************************************************************
//Función que basado en ciertas flags determina el estado del robot y lo muestra en un LED RGB.
//
//Utiliza flags relacionadas a si la bateria está baja, si se detecta un obstáculo, si el bluetooth no se ha conectado al dispositivo,
//si el robot está recibiendo un código, si el robot está ejecutando un código, y si el bluetooth está conectado con un dispositivo.
//El orden en el que se mencionaron los estados es el orden de prioridad.
//
//@param flagBateriaBaja Variable asociada a la señal de batería baja del powerboost, es LOW cuando batería baja.
//@param flagBluetooth Variable que dicta si hay conexión Bluetooth del robot con la App.
//@param flagEjecucion Variable que informa si se está ejecutando una programación.
//@param flagObstaculo Variable asociada a los sensores infrarrojos, informa cuando hay un obstáculo frente al robot
//@param recibeProgra Variable que es un pulso que se recibe cuando se está recibiendo/recibió una progra desde la App
//******************************************************************************************************************
void ConfigurarEstadoLedRgb(int flagBateriaBaja, bool flagBluetooth, bool flagEjecucion, bool flagObstaculo, bool recibeProgra, bool flagParar) {
  unsigned long tiempoActual = millis();

  //Bateria baja -> rojo parpadeante
  if (flagBateriaBaja == LOW) {
    // setear el tiempo de Encendido de LED en el momento de activar la flag
    if (tiempoActual <= tiempoDeEncendidoDeLed + duracionParpadeoLed && tiempoActual > tiempoDeEncendidoDeLed) {
      analogWrite(pinLedRgbRojo, 255);
      analogWrite(pinLedRgbVerde, 0);
      analogWrite(pinLedRgbAzul, 0);
      // Internal WS2812B mirrors external: red on
      leds[0] = CRGB(255, 0, 0);
      FastLED.show();

    } else if (tiempoActual > tiempoDeEncendidoDeLed + 2*duracionParpadeoLed) {
      //Se reinicia el "ciclo" de parpadeo
      tiempoDeEncendidoDeLed = millis();
      
    } else if (tiempoActual > tiempoDeEncendidoDeLed + duracionParpadeoLed){
      analogWrite(pinLedRgbRojo, 0);
      analogWrite(pinLedRgbVerde, 0);
      analogWrite(pinLedRgbAzul, 0);
      // Internal WS2812B mirrors external: off
      leds[0] = CRGB::Black;
      FastLED.show();
    }
   
  } else if (flagObstaculo == 1 || flagParar == 1) { //Obstaculo o paro de emergencia -> rojo fijo
    analogWrite(pinLedRgbRojo, 255);
    analogWrite(pinLedRgbVerde, 0);
    analogWrite(pinLedRgbAzul, 0);
    // Internal WS2812B mirrors external: red fixed
    leds[0] = CRGB(255, 0, 0);
    FastLED.show();

  } else if (flagBluetooth == 0) { //Bluetooth no conectado -> azul y verde intercalados
    // setear el tiempo de Encendido de LED en el momento de activar la flag
    if (tiempoActual <= tiempoDeEncendidoDeLed + duracionParpadeoLed && tiempoActual > tiempoDeEncendidoDeLed) {
      analogWrite(pinLedRgbRojo, 0);
      analogWrite(pinLedRgbVerde, 255);
      analogWrite(pinLedRgbAzul, 0);
      // Internal WS2812B mirrors external: green
      leds[0] = CRGB(0, 255, 0);
      FastLED.show();

    } else if (tiempoActual > tiempoDeEncendidoDeLed + 2*duracionParpadeoLed) {
      //Se reinicia el "ciclo" de parpadeo
      tiempoDeEncendidoDeLed = millis();
      
    } else if (tiempoActual > tiempoDeEncendidoDeLed + duracionParpadeoLed){
      analogWrite(pinLedRgbRojo, 0);
      analogWrite(pinLedRgbVerde, 0);
      analogWrite(pinLedRgbAzul, 255);
      // Internal WS2812B mirrors external: blue
      leds[0] = CRGB(0, 0, 255);
      FastLED.show();
    } 

  } else if (recibeProgra == 1) { //Recibe progra de la App -> azul parpadeante
    // setear el tiempo de Encendido de LED en el momento de activar la flag
    if (tiempoActual <= tiempoDeEncendidoDeLed + duracionParpadeoLed && tiempoActual > tiempoDeEncendidoDeLed) {
      analogWrite(pinLedRgbRojo, 0);
      analogWrite(pinLedRgbVerde, 0);
      analogWrite(pinLedRgbAzul, 255);
      // Internal WS2812B mirrors external: blue
      leds[0] = CRGB(0, 0, 255);
      FastLED.show();

    } else if (tiempoActual > tiempoDeEncendidoDeLed + 2*duracionParpadeoLed) {
      //Se reinicia el "ciclo" de parpadeo
      tiempoDeEncendidoDeLed = millis();
      
    } else if (tiempoActual > tiempoDeEncendidoDeLed + duracionParpadeoLed){
      analogWrite(pinLedRgbRojo, 0);
      analogWrite(pinLedRgbVerde, 0);
      analogWrite(pinLedRgbAzul, 0);
      // Internal WS2812B mirrors external: off
      leds[0] = CRGB::Black;
      FastLED.show();
    }

  } else if (flagEjecucion == 1) { //Robot ejecutando progra -> verde fijo
    analogWrite(pinLedRgbRojo, 0);
    analogWrite(pinLedRgbVerde, 255);
    analogWrite(pinLedRgbAzul, 0);
    // Internal WS2812B mirrors external: green fixed
    leds[0] = CRGB(0, 255, 0);
    FastLED.show();
    
  } else if (flagBluetooth == 1) { //Bluetooth conectado -> azul fijo
    analogWrite(pinLedRgbRojo, 0);
    analogWrite(pinLedRgbVerde, 0);
    analogWrite(pinLedRgbAzul, 255);
    // Internal WS2812B mirrors external: blue fixed
    leds[0] = CRGB(0, 0, 255);
    FastLED.show();
  }
}
