# Directorio Robot 

 Código para la programación del controlador del robot

 Lenguaje: C++
 Ambiente de programación: Arduino IDE
 Microncontrolador usado: IdeaBoard (basada en ESP32)

## Calibración persistente desde el firmware principal

Suba únicamente `CodigoESP32/CodigoESP32.ino`. En el primer arranque crea los
valores por defecto; después los conserva en la memoria no volátil del ESP32
(NVS), incluso si se vuelve a cargar una versión nueva del firmware.

Abra el Monitor Serial a **115200 baudios** y con terminación **Nueva línea**.
Para habilitar los comandos de calibración escriba:

```
DEV AttaDev2026
```

La clave está definida como `developerPassword` al inicio de `CodigoESP32.ino`;
cámbiela antes de distribuir el firmware. El acceso sirve como protección ante
cambios accidentales: una persona con acceso físico al USB y al código puede
leerla.

Una vez dentro:

```
SHOW
SET neutral 75
SET active 85
SET inactive 50
TEST 85
EXIT
```

`SET` guarda de inmediato. Los campos disponibles son `device`, `rppr`, `lppr`,
`kp`, `ki`, `kd`, `neutral`, `active`, `inactive`, `forward`, `reverse` y
`stop`. `TEST` mueve el servo del lápiz de forma temporal y no guarda nada.
Los valores `neutral`, `active` e `inactive` corresponden al servo de lápiz;
`forward`, `reverse` y `stop` al servo continuo del set de herramientas.

El sketch `CodigoESP32/Preferences/Preferences.ino` queda solo como referencia
legada y ya no escribe valores, para impedir que sobrescriba una calibración por
accidente.
